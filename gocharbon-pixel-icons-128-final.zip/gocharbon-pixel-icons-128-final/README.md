# GoCharbon Pixel Mine — icônes 128 px

Ce kit contient 60 icônes PNG individuelles prêtes pour le Web et Flutter/Android.

- Taille fixe : 128 × 128 px
- Couleur : RGBA 8 bits
- Fond : transparence alpha réelle
- Redimensionnement : filtre Point/Nearest, sans lissage
- Zone utile maximale : 112 × 112 px
- Marge transparente : au moins 8 px par côté
- Cadrage : centré, proportions conservées

Les cinq atlas d'origine sont conservés dans `atlases-sources/`.

## Affichage Web

Utiliser une largeur et une hauteur identiques. Pour conserver un rendu net lors d'un agrandissement :

```css
.pixel-icon {
  width: 64px;
  height: 64px;
  object-fit: contain;
  image-rendering: pixelated;
}
```

## Affichage Flutter

```dart
Image.asset(
  'assets/icons/pixel-mine/pack-1-gamification/01-footsteps.png',
  width: 64,
  height: 64,
  fit: BoxFit.contain,
  filterQuality: FilterQuality.none,
)
```
